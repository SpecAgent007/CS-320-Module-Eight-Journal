import java.util.ArrayList;
import java.util.List;

public class TaskService {
    // data structure to store tasks
    private List<Task> taskList;

    public TaskService() {
        taskList = new ArrayList<>();
    }

    public void addTask(Task task) {
     
        for (Task t : taskList) {
            if (t.getTaskId().equals(task.getTaskId())) {
                throw new IllegalArgumentException("Task ID already exists");
            }
        }
        taskList.add(task);
    }

    public void deleteTask(String taskId) {
        for (int i = 0; i < taskList.size(); i++) {
            if (taskList.get(i).getTaskId().equals(taskId)) {
                taskList.remove(i);
                return; // Task found and removed, exit the method
            }
        }
        // If the loop finishes and task wasn't found
        throw new IllegalArgumentException("Task ID not found");
    }

    public void updateTaskName(String taskId, String newName) {
        for (Task task : taskList) {
            if (task.getTaskId().equals(taskId)) {
                task.setName(newName); // The Task class handles the validation
                return;
            }
        }
        throw new IllegalArgumentException("Task ID not found");
    }

    public void updateTaskDescription(String taskId, String newDescription) {
        for (Task task : taskList) {
            if (task.getTaskId().equals(taskId)) {
                task.setDescription(newDescription); // The Task class handles the validation
                return;
            }
        }
        throw new IllegalArgumentException("Task ID not found");
    }
}