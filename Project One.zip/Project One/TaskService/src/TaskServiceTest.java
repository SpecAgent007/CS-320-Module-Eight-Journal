import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class TaskServiceTest {

    private TaskService service;

    @BeforeEach
    public void setUp() {
        // Creates a fresh instance of the service before every single test
        service = new TaskService();
    }

    @Test
    public void testAddTaskSuccess() {
        Task task = new Task("1", "Task Name", "Task Description");
        service.addTask(task);
        // If no exception is thrown, the addition was successful
    }

    @Test
    public void testAddDuplicateTaskFails() {
        Task task1 = new Task("1", "Task Name", "Task Description");
        Task task2 = new Task("1", "Another Name", "Another Description");
        service.addTask(task1);

        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            service.addTask(task2);
        });
    }

    @Test
    public void testDeleteTaskSuccess() {
        Task task = new Task("1", "Task Name", "Task Description");
        service.addTask(task);
        service.deleteTask("1");
        
        // Verifying the deletion by trying to delete it again, which should now throw an exception
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            service.deleteTask("1");
        });
    }

    @Test
    public void testDeleteTaskNotFound() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            service.deleteTask("999");
        });
    }

    @Test
    public void testUpdateTaskNameSuccess() {
        Task task = new Task("1", "Old Name", "Task Description");
        service.addTask(task);
        service.updateTaskName("1", "New Name");
        // Update executes without throwing an exception
    }

    @Test
    public void testUpdateTaskNameNotFound() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            service.updateTaskName("999", "New Name");
        });
    }

    @Test
    public void testUpdateTaskDescriptionSuccess() {
        Task task = new Task("1", "Task Name", "Old Description");
        service.addTask(task);
        service.updateTaskDescription("1", "New Description");
        // Update executes without throwing an exception
    }

    @Test
    public void testUpdateTaskDescriptionNotFound() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            service.updateTaskDescription("999", "New Description");
        });
    }
}