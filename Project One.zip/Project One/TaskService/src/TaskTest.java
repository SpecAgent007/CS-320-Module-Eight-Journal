import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class TaskTest {

    @Test
    public void testTaskCreationSuccess() {
        Task task = new Task("1234567890", "Test Name", "This is a test description.");
        Assertions.assertEquals("1234567890", task.getTaskId());
        Assertions.assertEquals("Test Name", task.getName());
        Assertions.assertEquals("This is a test description.", task.getDescription());
    }

    @Test
    public void testTaskIdTooLong() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345678901", "Test Name", "Test description");
        });
    }

    @Test
    public void testTaskIdNull() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new Task(null, "Test Name", "Test description");
        });
    }

    @Test
    public void testNameTooLong() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new Task("123", "This name is way too long to pass", "Test description");
        });
    }

    @Test
    public void testNameNull() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new Task("123", null, "Test description");
        });
    }

    @Test
    public void testDescriptionTooLong() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new Task("123", "Test Name", "This description is way too long because it goes over the fifty character limit.");
        });
    }

    @Test
    public void testDescriptionNull() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new Task("123", "Test Name", null);
        });
    }
}