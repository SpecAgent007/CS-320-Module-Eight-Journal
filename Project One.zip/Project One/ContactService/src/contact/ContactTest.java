package contact;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class ContactTest {

    @Test
    public void testContactSuccess() {
        Contact contact = new Contact("12345", "John", "Doe", "5551234567", "123 Elm St");
        
        assertEquals("12345", contact.getContactId());
        assertEquals("John", contact.getFirstName());
        assertEquals("Doe", contact.getLastName());
        assertEquals("5551234567", contact.getPhone());
        assertEquals("123 Elm St", contact.getAddress());
    }

    @Test
    public void testContactIdTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345678901", "John", "Doe", "5551234567", "123 Elm St");
        });
    }

    @Test
    public void testContactIdNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact(null, "John", "Doe", "5551234567", "123 Elm St");
        });
    }

    @Test
    public void testFirstNameInvalid() {
        // Test null
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", null, "Doe", "5551234567", "123 Elm St");
        });
        // Test > 10 chars
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "JohnathanLongName", "Doe", "5551234567", "123 Elm St");
        });
    }

    @Test
    public void testLastNameInvalid() {
        // Test null
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "John", null, "5551234567", "123 Elm St");
        });
        // Test > 10 chars
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "John", "DoeIsTooLongHere", "5551234567", "123 Elm St");
        });
    }

    @Test
    public void testPhoneInvalid() {
        // Test null
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "John", "Doe", null, "123 Elm St");
        });
        // Test less than 10 digits
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "John", "Doe", "12345", "123 Elm St");
        });
        // Test more than 10 digits
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "John", "Doe", "12345678901", "123 Elm St");
        });
        // Test non-digits
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "John", "Doe", "555123456a", "123 Elm St");
        });
    }

    @Test
    public void testAddressInvalid() {
        // Test null
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "John", "Doe", "5551234567", null);
        });
        // Test > 30 chars
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "John", "Doe", "5551234567", "1234567890 1234567890 12345678901");
        });
    }

    @Test
    public void testSetters() {
        Contact contact = new Contact("12345", "John", "Doe", "5551234567", "123 Elm St");
        
        contact.setFirstName("Jane");
        contact.setLastName("Smith");
        contact.setPhone("9998887777");
        contact.setAddress("456 Oak Ave");

        assertEquals("Jane", contact.getFirstName());
        assertEquals("Smith", contact.getLastName());
        assertEquals("9998887777", contact.getPhone());
        assertEquals("456 Oak Ave", contact.getAddress());
    }
}