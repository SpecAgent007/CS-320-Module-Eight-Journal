package contact;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class ContactServiceTest {
    private ContactService service;

    @BeforeEach
    public void setUp() {
        service = new ContactService();
    }

    @Test
    public void testAddContact() {
        Contact contact = new Contact("C1", "Bob", "Ross", "1234567890", "123 Happy Tree Ln");
        assertTrue(service.addContact(contact));
        assertEquals("Bob", service.findContact("C1").getFirstName());
    }

    @Test
    public void testAddDuplicateContact() {
        Contact contact1 = new Contact("C1", "Bob", "Ross", "1234567890", "123 Happy Tree Ln");
        Contact contact2 = new Contact("C1", "Rob", "Boss", "0987654321", "456 Sad Tree Ln");
        
        assertTrue(service.addContact(contact1));
        // Second add with same ID should fail
        assertFalse(service.addContact(contact2));
    }

    @Test
    public void testDeleteContact() {
        Contact contact = new Contact("C1", "Bob", "Ross", "1234567890", "123 Happy Tree Ln");
        service.addContact(contact);

        assertTrue(service.deleteContact("C1"));
        assertNull(service.findContact("C1"));
        // Trying to delete again should return false
        assertFalse(service.deleteContact("C1"));
    }

    @Test
    public void testUpdateFields() {
        Contact contact = new Contact("C1", "Bob", "Ross", "1234567890", "123 Happy Tree Ln");
        service.addContact(contact);

        assertTrue(service.updateFirstName("C1", "Bobby"));
        assertTrue(service.updateLastName("C1", "Smith"));
        assertTrue(service.updatePhone("C1", "1112223333"));
        assertTrue(service.updateAddress("C1", "789 New St"));

        Contact updated = service.findContact("C1");
        assertEquals("Bobby", updated.getFirstName());
        assertEquals("Smith", updated.getLastName());
        assertEquals("1112223333", updated.getPhone());
        assertEquals("789 New St", updated.getAddress());
    }

    @Test
    public void testUpdateNonExistentContact() {
        assertFalse(service.updateFirstName("FAKE_ID", "Alex"));
        assertFalse(service.updateLastName("FAKE_ID", "Smith"));
        assertFalse(service.updatePhone("FAKE_ID", "1234567890"));
        assertFalse(service.updateAddress("FAKE_ID", "123 Main St"));
    }
}