package contact;

import java.util.ArrayList;

public class ContactService {
    // In-memory list to store all contact objects
    private ArrayList<Contact> contactList;

    public ContactService() {
        contactList = new ArrayList<Contact>();
    }

    // Add contact if unique
    public boolean addContact(Contact newContact) {
        if (newContact == null) {
            return false;
        }

        // Check for duplicate ID
        for (int i = 0; i < contactList.size(); i++) {
            if (contactList.get(i).getContactId().equals(newContact.getContactId())) {
                return false; // ID already exists
            }
        }

        contactList.add(newContact);
        return true;
    }

    // Delete contact by contact ID
    public boolean deleteContact(String contactId) {
        if (contactId == null) {
            return false;
        }

        for (int i = 0; i < contactList.size(); i++) {
            if (contactList.get(i).getContactId().equals(contactId)) {
                contactList.remove(i);
                return true;
            }
        }
        return false; // Contact not found
    }

    // Update first name
    public boolean updateFirstName(String contactId, String newFirstName) {
        Contact contact = findContact(contactId);
        if (contact != null) {
            contact.setFirstName(newFirstName);
            return true;
        }
        return false;
    }

    // Update last name
    public boolean updateLastName(String contactId, String newLastName) {
        Contact contact = findContact(contactId);
        if (contact != null) {
            contact.setLastName(newLastName);
            return true;
        }
        return false;
    }

    // Update phone number
    public boolean updatePhone(String contactId, String newPhone) {
        Contact contact = findContact(contactId);
        if (contact != null) {
            contact.setPhone(newPhone);
            return true;
        }
        return false;
    }

    // Update address
    public boolean updateAddress(String contactId, String newAddress) {
        Contact contact = findContact(contactId);
        if (contact != null) {
            contact.setAddress(newAddress);
            return true;
        }
        return false;
    }

    // Helper method to find a contact by ID
    public Contact findContact(String contactId) {
        if (contactId == null) {
            return null;
        }
        for (Contact c : contactList) {
            if (c.getContactId().equals(contactId)) {
                return c;
            }
        }
        return null;
    }
}