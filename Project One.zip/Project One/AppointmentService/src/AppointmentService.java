import java.util.ArrayList;
import java.util.List;

public class AppointmentService {
    // In memory data structure 
    private List<Appointment> appointmentList;

    public AppointmentService() {
        appointmentList = new ArrayList<>();
    }

    public void addAppointment(Appointment appointment) {
        // Enforce unique appointment ID
        for (Appointment appt : appointmentList) {
            if (appt.getAppointmentId().equals(appointment.getAppointmentId())) {
                throw new IllegalArgumentException("Appointment ID already exists");
            }
        }
        appointmentList.add(appointment);
    }

    public void deleteAppointment(String appointmentId) {
        // Iterate through list to find and remove the appointment by ID
        for (int i = 0; i < appointmentList.size(); i++) {
            if (appointmentList.get(i).getAppointmentId().equals(appointmentId)) {
                appointmentList.remove(i);
                return; // Early exit once found
            }
        }
        throw new IllegalArgumentException("Appointment ID not found");
    }
}