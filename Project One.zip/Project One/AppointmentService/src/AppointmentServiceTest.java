import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.Calendar;
import java.util.Date;

public class AppointmentServiceTest {

    private AppointmentService service;
    private Date validDate;

    @BeforeEach
    public void setUp() {
        // Reset the service state and generate a fresh valid date before every test
        service = new AppointmentService();
        
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DAY_OF_MONTH, 5);
        validDate = calendar.getTime();
    }

    @Test
    public void testAddAppointmentSuccess() {
        Appointment appt = new Appointment("1", validDate, "Follow-up visit");
        service.addAppointment(appt);
        // Success is implied if no exceptions are thrown
    }

    @Test
    public void testAddDuplicateAppointmentFails() {
        Appointment appt1 = new Appointment("1", validDate, "First visit");
        Appointment appt2 = new Appointment("1", validDate, "Second visit");
        
        service.addAppointment(appt1);

        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            service.addAppointment(appt2);
        });
    }

    @Test
    public void testDeleteAppointmentSuccess() {
        Appointment appt = new Appointment("1", validDate, "Surgery prep");
        service.addAppointment(appt);
        service.deleteAppointment("1");
        
        // Assert the appointment is actually gone by trying to delete it again
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            service.deleteAppointment("1");
        });
    }

    @Test
    public void testDeleteAppointmentNotFound() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            service.deleteAppointment("999");
        });
    }
}