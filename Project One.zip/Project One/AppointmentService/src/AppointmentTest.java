import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import java.util.Calendar;
import java.util.Date;

public class AppointmentTest {

    // Helper method to dynamically generate a valid date in the future
    private Date getFutureDate() {
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DAY_OF_MONTH, 1); 
        return calendar.getTime();
    }

    // Helper method to dynamically generate an invalid date in the past
    private Date getPastDate() {
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DAY_OF_MONTH, -1);
        return calendar.getTime();
    }

    @Test
    public void testAppointmentCreationSuccess() {
        Date futureDate = getFutureDate();
        Appointment appt = new Appointment("12345", futureDate, "Annual checkup");
        
        Assertions.assertEquals("12345", appt.getAppointmentId());
        Assertions.assertEquals(futureDate, appt.getAppointmentDate());
        Assertions.assertEquals("Annual checkup", appt.getDescription());
    }

    @Test
    public void testAppointmentIdTooLong() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345678901", getFutureDate(), "Valid description");
        });
    }

    @Test
    public void testAppointmentIdNull() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new Appointment(null, getFutureDate(), "Valid description");
        });
    }

    @Test
    public void testAppointmentDateInPast() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345", getPastDate(), "Valid description");
        });
    }

    @Test
    public void testAppointmentDateNull() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345", null, "Valid description");
        });
    }

    @Test
    public void testDescriptionTooLong() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345", getFutureDate(), "This description is entirely too long because it well exceeds the fifty character limit.");
        });
    }

    @Test
    public void testDescriptionNull() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345", getFutureDate(), null);
        });
    }
}